<?php namespace tapacar\Events;

abstract class Event {

	//

}
