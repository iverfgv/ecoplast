<?php namespace tapacar;

use Illuminate\Database\Eloquent\Model;

class galeria extends Model {

	//
	protected $table = 'galeria';
}
