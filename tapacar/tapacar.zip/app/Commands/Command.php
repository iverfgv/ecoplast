<?php namespace tapacar\Commands;

abstract class Command {

	//

}
