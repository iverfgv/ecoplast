@extends('layouts.principal')

@section('content')
    @include('comprar.venta')   
@stop