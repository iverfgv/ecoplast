<!-- ABOUT
    ============================== -->
    <div class="site-wrapper" id="proteccion">



      <!--&lt;!&ndash; Heading &ndash;&gt;-->
      <!--<h1 class="heading">-->
      <!--En sólo <span class="text-warning">una hora</span> tu <span class="text-info">auto</span> puede convertirse en un <span class="text-danger">horno</span>. -->
      <!--</h1>-->

      <!--&lt;!&ndash; Sub heading &ndash;&gt;-->
      <!--<p class="heading__sub">-->
      <!--Si es INEVITABLE dejar tu carro a la intemperie, protégelo de la mejor forma con <span class="text-info">Tapa-Car</span>.-->
      <!--</p>-->
      <!--<div class="col-sm-8 col-md-offset-2" style="text-align:justify;">-->
      <!--<p>-->
      <!--El coche no absorbe tanta energía como para irradiarla hacia el exterior, de manera que sólo puede perder calor por conducción hacia otros cuerpos (cuando le ponemos una mano encima y nos quemamos) o por convección con el aire que lo rodea (que es más eficaz y lo más habitual).-->
      <!--</p>-->
      <!--<p>-->
      <!--Por su parte, dentro del habitáculo hay aire que se calienta al contacto con la estructura del vehículo y por convección va calentando al aire más frío… hasta que el interior del coche se transforma en un horno. Si las ventanas estuvieran abiertas, habría intercambio de temperatura con el aire exterior por convección y no se acumularía tanto calor en el interior. Pero, claro, dejar un coche con las ventanas abiertas no es una opción muy recomendable por motivos de seguridad frente a los amigos de lo ajeno.-->
      <!--</p>-->
      <!--</div>-->
      <!--</div>-->
      <!--<div class="col-sm-4 col-md-offset-2">-->
      <!--<br>-->
      <!--<br>-->
      <!--&lt;!&ndash; About item #1 &ndash;&gt;-->
      <!--<div class="about__item">-->
      <!--<h3 class="about-item__title">-->
      <!--<span class="about-item-title__icon oi oi-contrast" title="Fully responsive" aria-hidden="true"></span> 27°C Exterior-->
      <!--</h3>-->
      <!--<p class="about-item__content">-->
      <!--Temperatura ambiente fuera del carro.-->
      <!--</p>-->
      <!--</div> &lt;!&ndash; / .about__item &ndash;&gt;-->

      <!--</div>-->
      <!--<div class="col-sm-4">-->
      <!--<br>-->
      <!--<br>-->
      <!--&lt;!&ndash; About item #2 &ndash;&gt;-->
      <!--<div class="about__item">-->
      <!--<h3 class="about-item__title">-->
      <!--<span class="about-item-title__icon oi oi-sun" title="Built with LESS" aria-hidden="true"></span> 51° C Interior-->
      <!--</h3>-->
      <!--<p class="about-item__content">-->
      <!--La temperatura dentro del automóvil después de 60 minutos.-->
      <!--</p>-->
      <!--</div> &lt;!&ndash; / .about__item &ndash;&gt;-->
      <div>
        <h3 class="heading" style="color:white;">
          Si es INEVITABLE dejar tu carro a la intemperie,<br>protégelo de la mejor forma con <span class="text-info">TAPA-CAR</span>
        </h3>
      </div>
      <!-- <img src="img/screen-bg_11.jpg" class="img-responsive" id="todo"/> -->


    </div> <!-- / .site-wrapper_classic -->
