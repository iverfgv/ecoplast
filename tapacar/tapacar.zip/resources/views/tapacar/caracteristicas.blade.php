 <!-- TEAM
    ============================== -->
    <div class="site-wrapper" id="caracteristicas">
      <div class="container" >
        <div class="row">
          <div class="col-xs-12">

            <!-- Heading -->
            <h1 class="heading">
              Distribuidor de <span class="text-primary">TAPA-CAR</span>
            </h1>

            <!-- Sub heading -->
            <p>
             <h2 class="heading">Que esperas y se parte de <span class="text-primary">TAPA-CAR</span>
              como distribuidor autorizado 
              </h2>

           </p>

         </div>
       </div> <!-- / .row -->
        <div class="row">
              <div class="col-xs-2"></div> 
              <div class="col-xs-8"><img class="img-responsive" src="img/tapa.png"></div> 
              <div class="col-xs-2"></div> 
           </div>
     </div> <!-- / .container -->

   </div> <!-- / .site-wrapper -->