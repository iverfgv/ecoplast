@extends('layouts.principal')

@section('content')
    @include('tapacar.bienvenido')
    @include('tapacar.protecion')
    @include('tapacar.comprar')
    @include('tapacar.colocacion')
    @include('tapacar.caracteristicas')
    @include('tapacar.comparacion')
    @include('tapacar.contacto')    
@stop