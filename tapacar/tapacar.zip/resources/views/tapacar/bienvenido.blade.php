<div class="welcome_classic" id="inicio">
      <div class="welcome-classic__inner">
        <div class="container">
            <div class="row" style="margin-top:6%;">
            <div class="col-xs-12">

              <!-- Pre heading -->
              <!-- <p class="heading__pre">
                Version 2.2.0
              </p> -->

              <!-- Heading -->
              <!-- <h1 class="heading heading_lg">
                TAPA-<span class="text-info">CAR</span>
              </h1> -->
              <!-- ***********Imagen principal -->

              <!-- <center><img src="img/logo.png" class="img-responsive" style="width: 20%;" /></center> -->

              <!-- Sub heading -->
              <!--<p class="heading__sub">-->
              <!--Es la mejor solución para proteger tu auto donde quiera que estés.-->
              <!--</p>-->       

              <div id="carousel-banner" class="carousel slide espacio" data-ride="carousel">
                <ol class="carousel-indicators">
                  <li data-target="#carousel-banner" data-slide-to="0" class="active"></li>
                  <li data-target="#carousel-banner" data-slide-to="1"></li>
                  <li data-target="#carousel-banner" data-slide-to="2"></li>
                  <li data-target="#carousel-banner" data-slide-to="3"></li>
                  <li data-target="#carousel-banner" data-slide-to="4"></li>
                  <li data-target="#carousel-banner" data-slide-to="5"></li>
                </ol>

                  <div class="carousel-inner" role="listbox">
                    <div class="item active" id="center-img">
                      <img id="galery-center" src="img/galeria/img.jpg" alt="...">
                      <div class="carousel-caption">
                        <h1>Tapacar</h1>
                        <h3>La nueva solución para proteger tu auto a donde quiera que vayas.</h3>
                      </div>
                    </div>
                    <div class="item" id="center-img">
                      <img id="galery-center" src="img/galeria/img1.png" alt="...">
                      <div class="carousel-caption">
                        <h1>Tapacar</h1>
                        <h3>La nueva solución para proteger tu auto a donde quiera que vayas.</h3>
                      </div>
                    </div>
                    <div class="item" id="center-img">
                      <img id="galery-center" src="img/galeria/img2.jpg" alt="...">
                      <div class="carousel-caption">
                        <h1>Tapacar</h1>
                        <h3>La nueva solución para proteger tu auto a donde quiera que vayas.</h3>
                      </div>
                    </div>
                       <div class="item" id="center-img">
                      <img id="galery-center" src="img/galeria/img3.jpg" alt="...">
                      <div class="carousel-caption">
                        <h1>Tapacar</h1>
                        <h3>La nueva solución para proteger tu auto a donde quiera que vayas.</h3>
                      </div>
                    </div>
                       <div class="item" id="center-img">
                      <img id="galery-center" src="img/galeria/img4.jpg" alt="...">
                      <div class="carousel-caption">
                        <h1>Tapacar</h1>
                        <h3>La nueva solución para proteger tu auto a donde quiera que vayas.</h3>
                      </div>
                    </div>
                       <div class="item" id="center-img">
                      <img id="galery-center" src="img/galeria/img5.jpg" alt="...">
                      <div class="carousel-caption">
                        <h1>Tapacar</h1>
                        <h3>La nueva solución para proteger tu auto a donde quiera que vayas.</h3>
                      </div>
                    </div>
                  </div>

              <a class="left carousel-control" href="#carousel-banner" role="button" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="right carousel-control" href="#carousel-banner" role="button" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>
          </div>

              <!-- Button -->
              <div class="text-center">

                <a href="#comprar" class="btn btn-xl btn-primary2">
                  <span class="oi oi-arrow-right" title="Find out more" aria-hidden="true"></span>
                  <span>Más detalles</span>
                </a>
                <a href="#comprar" class="btn btn-xl btn-primary1">
                  <span class="oi oi-arrow-right" title="Find out more" aria-hidden="true"></span>
                  <span>Comprar ahora</span>
                </a>

              </div>

            </div>
          </div> <!-- / .row -->
       <!--    <div class="row" style="text-align:center; margin-top:10%; background-color: white;">
            <h1 class="text-primary">
              <span class="text-info">TAPA-CAR</span> ES LA MEJOR SOLUCIÓN<br>PARA PROTEGER TU AUTO DONDE QUIERA QUE ESTÉS
            </h1>
          </div> -->
        </div> <!-- / .container -->
      </div> <!-- / .classic-welcome__inner -->
    </div> <!-- / .welcome_classic -->
