@extends('layouts.principal')
<div id='error'>
 	<h1 id='error404'>Página no encontrada</h1>
</div>